Clicklate
=========

Context menu quick translate extension for Google Chrome browser.

Now available on [Chrome Web Store](https://chrome.google.com/webstore/detail/clicklate/kjeeaojnfbcledliboggbfklmomlalkj)

=========

Google Chrome için sağ tık menüsü çeviri uzantısı.

Clicklate artık [Chrome Web Mağazası'nda](https://chrome.google.com/webstore/detail/clicklate/kjeeaojnfbcledliboggbfklmomlalkj)
