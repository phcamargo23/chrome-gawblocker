Simple chrome extension that translates words under cursor.
